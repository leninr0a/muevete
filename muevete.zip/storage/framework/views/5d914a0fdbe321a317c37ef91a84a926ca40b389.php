<?php $__env->startSection('title','Reg&iacute;strate en Mu&eacute;vete'); ?>

<?php $__env->startSection('content'); ?>
	
<div class="register-page">		
	<div class="bg-black">
	<div class="container container-register">
	<div class="row">
		<div class="col-xs-4 col-yellow"></div>
		<div class="col-xs-4 col-blue"></div>
		<div class="col-xs-4 col-red"></div>
	</div>
		<div class="row">
			<div class="col-xs-12 text-left">
				<h2 class="header-register">Reg&iacute;strate</h2>

			</div>
		</div>
		<div class="row">
			<div class="col-xs-12">
				<?php if($errors->count()): ?>
				<div class="alert alert-danger">
					<p><strong>Oops!</strong> Por favor corrija los siguientes campos:</p>
					<ul>
						<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
						<li><?php echo e($error); ?></li>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
					</ul>
				</div>
				<?php endif; ?>
			</div>
		</div>
		<form action="<?php echo e(url('register/user')); ?>" method="POST">
			<div class="row row-register-form">
				<div class="col-xs-2">
					<p>C&eacute;dula</p>
					<select name="nacionalidad" class="form-control">
						<option value="V">V</option>
						<option value="E">E</option>
					</select>
				</div>
				<div class="col-xs-4 cedula-field-col">
					<p>&nbsp;</p>
					<input type="text"  pattern="[0-9]{6,}" name="cedula" class="form-control" value="<?php echo e(old('cedula')); ?>" placeholder="Ej: 1234567"required>
				</div>
				<div class="col-xs-6">
					<p>G&eacute;nero</p>
					<select name="genero" class="form-control">
						<option value="M">M&aacute;sculino</option>
						<option value="F">Femenino</option>
					</select>
				</div>
				
			</div>
			<div class="row row-register-form">

				<div class="col-xs-6 ">
					<p>Nombre</p>
					<input type="text" name="nombre" value="<?php echo e(old('nombre')); ?>" class="form-control" required>
				</div>
				<div class="col-xs-6">
					<p>Apellido</p>
					<input type="text" name="apellido" value="<?php echo e(old('apellido')); ?>" class="form-control" required>
				</div>
			</div>
			<div class="row row-register-form">
				<div class="col-xs-6 ">
					<p>Email</p>
					<input type="email" name="email" value="<?php echo e(old('email')); ?>" class="form-control" placeholder="ejemplo@correo.com" required>
				</div>
				<div class="col-xs-6 ">
					<p>Tel&eacute;fono (fijo o m&oacute;vil)</p>
					<input type="tel" pattern="[0-9].{10,11}" name="telefono" value="<?php echo e(old('telefono')); ?>" class="form-control" placeholder="Ej: 04121626213 o 02742529362" required>
				</div>
			</div>
			<div class="row row-register-form">
				<div class="col-xs-6 ">
					<p>Contrase&ntilde;a</p>
					<input type="password" name="password" class="form-control" required>
				</div>
				<div class="col-xs-6">
					<p>Repetir contrase&ntilde;a</p>
					<input type="password" name="password_confirmation" class="form-control" required>
				</div>
				
			</div>
			<div class="row row-register-form">
				<div class="col-xs-6 ">
					
					<p><small>Al registrarme, declaro que soy mayor de edad y acepto las <a href="">Pol&iacute;ticas de privacidad</a> y los <a href="">T&eacute;rminos y condiciones de uso</a></small></p>
				</div>
				<div class="col-xs-3 btn-col">
					<button class="btn btn-registrarme" type="submit">Registrarme</button>
				</div>
				<div class="col-xs-6 col-xs-offset-3">
						<hr class="">
				</div>
			</div>
			<?php echo e(csrf_field()); ?>

		</form>

		<div class="row">

			<div class="col-xs-12 text-center">
				<h3>o inicia sesi&oacute;n con un click usando tu Facebook</h3>
				<a href="" class="btn-facebook-login"><img src="images/btn_facebook.png" class="img-responsive" alt=""></a>
			</div>
		</div>
	</div>
	</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>