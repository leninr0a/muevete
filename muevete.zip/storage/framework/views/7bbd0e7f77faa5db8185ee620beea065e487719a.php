<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title><?php echo $__env->yieldContent('title'); ?></title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" href="<?php echo e(URL::asset('css/styles.css')); ?> ">
	<link rel="stylesheet" href="<?php echo e(URL::asset('css/animate.css')); ?> "> 
	<link rel="stylesheet" href="<?php echo e(URL::asset('css/bootstrap-datepicker.min.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(URL::asset('css/bootstrap-timepicker.min.css')); ?>">
	<link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet">

</head>
<header class="header">
		<div class="container">
			<div class="row menu-row">
				<div class="col-xs-2 col-logo">
					<img src="<?php echo e(URL::asset('images/logo-2.png')); ?>" class="img-responsive" alt="">
				</div>
				<div class="col-xs-10 text-right">
					<ul class="menu navbar navbar-right">
						<a href="<?php echo e(url('/')); ?>"><li>Inicio</em></li></a>
						<a href="<?php echo e(url('publicar')); ?>"><li>Publicar viaje</li></a>
						
						 <!-- Authentication Links -->
                        <?php if(Auth::guest()): ?>
                            <a href="<?php echo e(url('register')); ?>"><li>Registrarse</li></a>
                            <li class="dropdown">
		                        <a  class="dropdown-toggle menu-link" data-toggle="dropdown">Ingresar <span class="caret"></span></a>
		                        <ul class="dropdown-menu dropdown-lr animated flipInX" role="menu">
		                          	<li class="row">
		                          		<form action="<?php echo e(url('/login')); ?>" method="POST">
		                          			<?php echo e(csrf_field()); ?>

			                          		<div class="col-xs-12">
			                          			<div class="input-group">	
													<span class="input-group-addon"><i class="fa fa-at fa-log-in"></i></span><input type="email" name="email" class="form-control input-login" placeholder="E-mail"  required>
			                          			</div>
			                          		</div>
			                          		<div class="col-xs-12">
			                          			<div class="input-group">	
													<span class="input-group-addon"><i class="fa fa-lock fa-log-in">	</i></span><input type="password" name="password" class="form-control input-login" placeholder="Contrase&ntilde;a" required >
			                          			</div>
			                          		</div>

			                          		<div class="col-xs-12 text-center">	
			                          				<button class="btn-log-in" type="submit">Iniciar sesi&oacute;n</button>
			                          		</div>
		                          		</form>
		                          		<p class="text-center"><a href=""><small>¿Olvidaste tu contrase&ntilde;a?</small></a></p>
		                          		<div class="col-xs-12 ">
		                          				<hr>	
		                          			<img src="images/btn_facebook.png" class="img-responsive" alt="">
		                          		</div>
		                          		
		                          	</li>
		                        </ul>
	                    	</li>
                        <?php else: ?>
                        	<a href="<?php echo e(url('/mi-cuenta/perfil')); ?>"><li><?php echo e(Auth::user()->nombre); ?> <i class="fa fa-user-o"></i></li></a>
                        	<a href="<?php echo e(url('/logout')); ?>" onclick="event.preventDefault();document.getElementById('logout-form').submit();">
                        	<li>Salir <i class="fa fa-close"></i>
							<form id="logout-form" action="<?php echo e(url('/logout')); ?>" method="POST" style="display: none;">
                            <?php echo e(csrf_field()); ?></form></li></a>
                           
                                        
                                
                        <?php endif; ?>
					</ul>
				</div>
			</div>
		</div>
	</header>

<body>
	
	<section class="contenido">
		<?php echo $__env->yieldContent('content'); ?>


		<footer>
		<div class="container">
			<div class="row">
				<div class="col-xs-12">
					<p><small>&copy; 2016 Mu&eacute;vete. Todos los derechos reservados.</small></p>
				</div>
			</div>
		</div>
	</footer>
	</section>
	



  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <script src="<?php echo e(URL::asset('js/bootstrap-datepicker.min.js')); ?>"></script>
  <script src="<?php echo e(URL::asset('js/bootstrap-timepicker.min.js')); ?>"></script>
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDV8O_HBXu0qinR_zAaUEzgWqbFtd3N2os&signed_in=true&libraries=places&callback=initAutocomplete&region=VE"
        async defer></script>
  <?php echo $__env->yieldContent('additionalScript'); ?>
</body>
</html>