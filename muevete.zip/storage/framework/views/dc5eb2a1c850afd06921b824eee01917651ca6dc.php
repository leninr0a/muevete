<?php if($errors->count()): ?>
	<div class="alert alert-danger">
	    <p><strong>Oops!</strong> Por favor corrija los siguientes campos:</p>
	    <ul>
	        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
	        <li><?php echo e($error); ?></li>
	        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
	    </ul>
	</div>
<?php endif; ?>